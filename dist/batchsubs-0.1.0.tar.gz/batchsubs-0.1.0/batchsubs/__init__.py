"""
 Created by waldo on 3/17/17
"""

__author__ = "waldo"
__project__ = "batchsubs"
 

